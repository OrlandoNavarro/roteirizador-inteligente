# Roteirizador Inteligente

Back-end em FastAPI com Docker pronto para deploy na Fly.io.
