# Roteirizador Inteligente (Dockerizado)

Projeto de roteirização com FastAPI, pronto para rodar via Docker.

## Comandos úteis

### Subir o container
```bash
docker-compose up --build
```

### Acessar API
Acesse em: http://localhost:8000

